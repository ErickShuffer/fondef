<?php

header("Location: public/");
